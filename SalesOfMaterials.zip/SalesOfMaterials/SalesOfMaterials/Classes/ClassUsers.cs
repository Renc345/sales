﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    internal class ClassUsers
    {
        public static ClassUsers GetUsers { get; set; }
        public int ID { get; set; }
        public string FIO { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Type { get; set; }
        public ClassUsers(Employee employee)
        {
            ID = employee.IdEmployee;
            FIO = employee.FIO;
            Login = employee.Login_Employee;
            Password = employee.Password_Employee;
            Type = employee.TypesEmployee.Nazv_type;
            GetUsers = this;

        }
    }
}
