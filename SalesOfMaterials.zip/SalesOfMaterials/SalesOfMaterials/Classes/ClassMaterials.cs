﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace SalesOfMaterials.Classes
{
    internal class ClassMaterials
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string DrawingNumber { get; set; }
        public string Types { get; set; }


    }
}
