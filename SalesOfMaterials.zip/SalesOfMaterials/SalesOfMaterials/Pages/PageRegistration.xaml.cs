﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageRegistration.xaml
    /// </summary>
    public partial class PageRegistration : Page
    {
        public PageRegistration()
        {
            InitializeComponent();
            cmbRole.ItemsSource = ClassFrame.db.TypesEmployee.ToList();
        }

        private void btnregistration_Click(object sender, RoutedEventArgs e)
        {
            Employee employee = new Employee();
            if (login.Text == "" && password.Password == "")
            {
                MessageBox.Show("Введите данные в поле","Ошибка ввода",MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            employee.FIO = FIO.Text;
            employee.Login_Employee = login.Text;
            employee.Password_Employee = password.Password;
            TypesEmployee role = (TypesEmployee)cmbRole.SelectedItem;
            employee.IdTypesEmployee = role.IdTypesEmployee;
            try
            {
                ClassFrame.db.Employee.Add(employee);
                ClassFrame.db.SaveChanges();
                MessageBox.Show("Все успешно добавлено");
                ClassFrame.frmObj.Navigate(new PageAuthorization());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnenter_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAuthorization());
        }

        private void check_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (check.Password != password.Password)
            {
                btnregistration.IsEnabled = false;
                check.Background = Brushes.LightCoral;
                check.BorderBrush = Brushes.Red;
            }
            else
            {
                btnregistration.IsEnabled = true;
                check.Background = Brushes.LightGreen;
                check.BorderBrush = Brushes.Green;
            }
        }
    }
}
