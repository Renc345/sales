﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            List<ExpenseIvoices> ivoices = ClassFrame.db.ExpenseIvoices.ToList();
            foreach (ExpenseIvoices i in ivoices)
                i.Warehouses = ClassFrame.db1.Warehouses.FirstOrDefault(x => x.idWarehouse == i.IdWarehouse);
            dgExpenseIvoices.ItemsSource = ivoices;
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            var OrderForRemoving = dgExpenseIvoices.SelectedItems.Cast<ExpenseIvoices>().ToList();
            if (MessageBox.Show("Удалить заказы", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ClassFrame.db.ExpenseIvoices.RemoveRange(OrderForRemoving);
                    ClassFrame.db.SaveChanges();
                    MessageBox.Show("Данные удаленны");
                    dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
                }
                catch(Exception ex) 
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void dgExpenseIvoices_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageExpenseComposition((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }
    }
}
